### Hexlet tests and linter status:
[![Actions Status](https://github.com/byMystick/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/byMystick/python-project-49/actions)
<a href="https://codeclimate.com/github/byMystick/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/a7a4cebc82fa263897c1/maintainability" /></a>
<a href="https://codeclimate.com/github/byMystick/python-project-49/test_coverage"><img src="https://api.codeclimate.com/v1/badges/a7a4cebc82fa263897c1/test_coverage" /></a>
